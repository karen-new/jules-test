package com.example.taskmatrix;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskmatrixApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskmatrixApplication.class, args);
	}

}
