package com.example.taskmatrix;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskmatrixApplicationTests {

	@Test
	void contextLoads() {
	}

}
